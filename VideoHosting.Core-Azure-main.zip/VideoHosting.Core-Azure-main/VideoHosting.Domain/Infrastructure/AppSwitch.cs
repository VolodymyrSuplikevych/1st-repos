﻿namespace VideoHosting.Domain.Infrastructure
{
    public class AppSwitch
    {
        public string Key { get; set; } 

        public string Value { get; set; } 
    }
}
