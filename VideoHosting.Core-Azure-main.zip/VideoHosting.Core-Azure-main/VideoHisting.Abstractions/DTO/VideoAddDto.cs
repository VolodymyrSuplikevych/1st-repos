﻿
namespace VideoHosting.Abstractions.Dto
{
    public class VideoAddDto
    {
        public string UserId { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string PhotoPath { get; set; }

        public string VideoPath { get; set; }
    }
}
