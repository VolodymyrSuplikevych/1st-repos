﻿namespace VideoHosting.Abstractions.Repositories
{
    public interface IAppSwitchRepository
    {
        string GetValue(string key);
    }
}
