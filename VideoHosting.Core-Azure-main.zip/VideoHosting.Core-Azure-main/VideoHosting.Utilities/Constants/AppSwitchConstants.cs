﻿
namespace VideoHosting.Utilities.Constants
{
    public static class AppSwitchConstants
    {
        public static string UserPhotoKey = "UserPhoto";

        public static string VideoPhotoKey = "VideoPhoto";

        public static string VideoKey = "Video";
    }
}
