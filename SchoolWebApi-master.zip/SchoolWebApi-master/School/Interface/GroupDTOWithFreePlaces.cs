﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School.Interface
{
    public class GroupDTOWithFreePlaces:GroupDTO
    { 
        public int FreePlaces { get; set; }
    }
}
